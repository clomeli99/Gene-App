package com.example.clomeli.genecademy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Scanner;

import stanford.androidlib.SimpleActivity;

public class DetailsActivity extends SimpleActivity {

    TextView geneName;
    ImageView chromepic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        geneName =$(R.id.geneName);
        chromepic = $(R.id.chromepic);
        Intent intent = getIntent();
        String name = (String) intent.getExtras().get("gene");
        geneName.setText(name);
        name = name.toLowerCase();
//        int txtid = getResources().getIdentifier(name, "raw", getPackageName());
//        Scanner txtscan = new Scanner(getResources().openRawResource(txtid));
        int pngid = getResources().getIdentifier(name, "drawable", getPackageName());
        chromepic.setImageResource(pngid);

    }
}
